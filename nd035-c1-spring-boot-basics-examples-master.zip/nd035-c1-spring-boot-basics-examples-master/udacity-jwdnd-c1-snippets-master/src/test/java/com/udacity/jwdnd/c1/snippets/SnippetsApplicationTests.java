package com.udacity.jwdnd.c1.snippets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnippetsApplicationTests {

    @Test
    void contextLoads() {
    }

}
