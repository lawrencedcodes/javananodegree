package com.udacity.jwdnd.c1.snippets.l4;

public class User {
    private String username;
    private String salt;
    private String password;
    private String firstName;
    private String lastName;







}
