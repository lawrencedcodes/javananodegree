package com.udacity.jwdnd.c1.snippets.l2;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    public UserProfile getUserProfile(String username) {
        // fetch data from database
        UserProfile result = new UserProfile();

        // set the UserProfile's fields

        return result;
    }

}

