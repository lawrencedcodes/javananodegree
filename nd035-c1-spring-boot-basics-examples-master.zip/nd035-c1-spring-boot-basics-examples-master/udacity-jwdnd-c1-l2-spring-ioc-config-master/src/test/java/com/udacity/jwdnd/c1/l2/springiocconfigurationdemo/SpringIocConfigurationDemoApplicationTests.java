package com.udacity.jwdnd.c1.l2.springiocconfigurationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocConfigurationDemoApplicationTests {

    @Test
    void contextLoads() {

    }

}
