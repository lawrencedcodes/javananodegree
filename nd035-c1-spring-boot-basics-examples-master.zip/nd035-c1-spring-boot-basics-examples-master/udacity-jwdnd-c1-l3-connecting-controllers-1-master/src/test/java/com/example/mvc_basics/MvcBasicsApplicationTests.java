package com.example.mvc_basics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcBasicsApplicationTests {

    @Test
    void contextLoads() {
    }

}
