package com.udacity.jwdnd.spring_security_basics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityBasicsApplicationTests {

    @Test
    void contextLoads() {
    }

}
