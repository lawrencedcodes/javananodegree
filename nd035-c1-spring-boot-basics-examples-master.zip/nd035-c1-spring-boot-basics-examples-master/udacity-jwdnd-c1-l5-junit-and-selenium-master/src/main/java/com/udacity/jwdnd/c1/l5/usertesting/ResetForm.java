package com.udacity.jwdnd.c1.l5.usertesting;

public class ResetForm {

    private Integer value;

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
