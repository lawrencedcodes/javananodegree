package com.example.demo;

public class SeleniumTest {
    public static void main(String[] args) throws InterruptedException {
        
    }
}
